// Content script runs on the active webpage
// Listen for messages from the popup

// Apply initial state if already set
const currentModes = [
    'highContrastMode', 'lowVisionMode', 'colorBlindMode',
    'tunnelVisionMode', 'peripheralLossMode', 'blurryVisionMode',
    'focusMode', 'smartHighlightMode', 'largeCursorMode', 'voiceMode',
    'removeImagesMode', 'magnifierMode'
];
let isLoggedIn = false;
  
function initializeModes() {
    if (!document.body) {
        setTimeout(initializeModes, 50);
        return;
    }
    chrome.storage.local.get([...currentModes, 'lowVisionLevel', 'isLoggedIn'], (result) => {
        isLoggedIn = !!result.isLoggedIn;

        if (result.lowVisionLevel) {
            updateLowVisionSize(result.lowVisionLevel);
        } else {
            updateLowVisionSize(3); // Default
        }

        Object.keys(result).forEach(mode => {
            if (currentModes.includes(mode) && result[mode]) {
                applyMode(mode, true);
                if (mode === 'voiceMode') isVoiceModeEnabled = true;
            }
        });
    });
}

initializeModes();
  
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("[SightSync] Message received:", request);
    if (request.action === "toggleMode") {
        console.log(`[SightSync] Toggling mode: ${request.mode} => ${request.value}`);
        applyMode(request.mode, request.value);
    } else if (request.action === "resetAllModes") {
        console.log("[SightSync] Resetting all modes");
        currentModes.forEach(mode => applyMode(mode, false));
    } else if (request.action === "updateLowVisionLevel") {
        updateLowVisionSize(request.level);
    } else if (request.action === "showLoginModal") {
        showLoginModal();
    }
    sendResponse({ received: true });
    return true;
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "loginSuccess") {
        isLoggedIn = true;
        const overlay = document.getElementById('sightsync-login-overlay');
        if (overlay) overlay.remove();
    }
});

function showLoginModal() {
    if (document.getElementById('sightsync-login-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'sightsync-login-overlay';
    overlay.className = 'sightsync-modal-overlay';
    
    overlay.innerHTML = `
        <div class="sightsync-login-modal" id="sightsync-login-modal">
            <button class="sightsync-close-btn" id="sightsync-close-modal">×</button>
            <div class="sightsync-login-header">
                <h1>SightSync</h1>
                <p>Login to access features</p>
            </div>
            <button id="ssGoogleLoginBtn" class="sightsync-btn sightsync-btn-primary" style="display: flex; align-items: center; justify-content: center; gap: 10px;">
                <svg width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
                Sign in with Google
            </button>
        </div>
    `;
    
    document.body.appendChild(overlay);

    document.getElementById('sightsync-close-modal').addEventListener('click', () => {
        overlay.remove();
    });

    document.getElementById('ssGoogleLoginBtn').addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: "startGoogleAuth" }, (response) => {
            if (response && response.success) {
                isLoggedIn = true;
                overlay.remove();
            } else {
                console.error("Login failed:", response?.error);
            }
        });
    });
    
    // Prevent modal clicks from closing overlay if we add that later
    document.getElementById('sightsync-login-modal').addEventListener('click', (e) => {
        e.stopPropagation();
    });
}

function updateLowVisionSize(level) {
    const size = 40 + (level * 10);
    document.documentElement.style.setProperty('--low-vision-size', `${size}px`, 'important');
}

let ttsUtterance = null;
let tunnelOverlay = null;
let isVoiceModeEnabled = false;
let debouncedReadVisible = null;
let debouncedMouseMove = null;

function applyMode(mode, enable) {
    const body = document.body;
    switch(mode) {
        case 'highContrastMode':
            enable ? body.classList.add('access-high-contrast') : body.classList.remove('access-high-contrast');
            break;

        case 'lowVisionMode':
            enable ? body.classList.add('access-low-vision') : body.classList.remove('access-low-vision');
            break;

        case 'colorBlindMode':
            enable ? body.classList.add('access-color-blind') : body.classList.remove('access-color-blind');
            break;

        case 'tunnelVisionMode':
            if (enable) {
                if(!tunnelOverlay) {
                    tunnelOverlay = document.createElement('div');
                    tunnelOverlay.className = 'access-tunnel-overlay';
                    document.body.appendChild(tunnelOverlay);
                    
                    // Optional: Make it follow cursor
                    document.addEventListener('mousemove', moveTunnel);
                }
            } else {
                if(tunnelOverlay) {
                    document.removeEventListener('mousemove', moveTunnel);
                    tunnelOverlay.remove();
                    tunnelOverlay = null;
                }
            }
            break;

        case 'peripheralLossMode':
            enable ? body.classList.add('access-peripheral') : body.classList.remove('access-peripheral');
            break;

        case 'blurryVisionMode':
            enable ? body.classList.add('access-blurry-vision') : body.classList.remove('access-blurry-vision');
            break;

        case 'focusMode':
            if (enable) {
                body.classList.add('access-focus');
                applyFocusModeEnhancements();
            } else {
                body.classList.remove('access-focus');
                removeFocusModeEnhancements();
            }
            break;

        case 'smartHighlightMode':
            enable ? body.classList.add('access-smart-highlight') : body.classList.remove('access-smart-highlight');
            break;

        case 'largeCursorMode':
            if (enable) {
                startLargeCursor();
            } else {
                stopLargeCursor();
            }
            break;

        case 'voiceMode':
            if (enable) {
                startVoiceMode();
            } else {
                stopVoiceMode();
            }
            break;

        case 'removeImagesMode':
            enable ? body.classList.add('access-remove-images') : body.classList.remove('access-remove-images');
            break;

        case 'magnifierMode':
            if (enable) {
                startMagnifier();
            } else {
                stopMagnifier();
            }
            break;
    }
}

function moveTunnel(e) {
    if(tunnelOverlay) {
        tunnelOverlay.style.transform = `translate(calc(${e.clientX}px - 150px), calc(${e.clientY}px - 150px))`;
    }
}

// -----------------------------------
// Focus Mode Functions
// -----------------------------------
let focusModeHiddenElements = [];

function applyFocusModeEnhancements() {
    // If page lacks semantic <main>/<article>, try to find the largest content block
    const hasMain = document.querySelector('main, article, [role="main"]');
    if (!hasMain) {
        console.log('[SightSync] No semantic main content found, applying fallback focus mode');
        // Find the largest text-heavy div as the "main" content
        const divs = document.querySelectorAll('body > div, body > section');
        let bestDiv = null;
        let bestTextLen = 0;
        divs.forEach(div => {
            const textLen = (div.innerText || '').length;
            if (textLen > bestTextLen) {
                bestTextLen = textLen;
                bestDiv = div;
            }
        });
        if (bestDiv && bestTextLen > 200) {
            bestDiv.setAttribute('data-sightsync-main', 'true');
            bestDiv.style.maxWidth = '750px';
            bestDiv.style.margin = '0 auto';
            bestDiv.style.padding = '24px';
            bestDiv.style.fontSize = '1.15em';
            bestDiv.style.lineHeight = '1.9';
        }
        // Hide other top-level siblings
        divs.forEach(div => {
            if (div !== bestDiv && !div.querySelector('[data-sightsync-main]')) {
                const textLen = (div.innerText || '').length;
                if (textLen < 100) {
                    div.setAttribute('data-sightsync-hidden', 'true');
                    div.style.display = 'none';
                    focusModeHiddenElements.push(div);
                }
            }
        });
    }
}

function removeFocusModeEnhancements() {
    // Restore fallback-hidden elements
    focusModeHiddenElements.forEach(el => {
        el.style.display = '';
        el.removeAttribute('data-sightsync-hidden');
    });
    focusModeHiddenElements = [];
    // Remove fallback main styling
    const fallbackMain = document.querySelector('[data-sightsync-main]');
    if (fallbackMain) {
        fallbackMain.style.maxWidth = '';
        fallbackMain.style.margin = '';
        fallbackMain.style.padding = '';
        fallbackMain.style.fontSize = '';
        fallbackMain.style.lineHeight = '';
        fallbackMain.removeAttribute('data-sightsync-main');
    }
}



// -----------------------------------
// Large Cursor Mode Functions
// -----------------------------------
let largeCursorDot = null;
let largeCursorHalo = null;
let largeCursorMoveHandler = null;

function startLargeCursor() {
    document.body.classList.add('access-large-cursor');

    if (!largeCursorDot) {
        largeCursorDot = document.createElement('div');
        largeCursorDot.className = 'access-large-cursor-dot';
        largeCursorDot.style.left = '-100px';
        largeCursorDot.style.top = '-100px';
        document.body.appendChild(largeCursorDot);
    }
    if (!largeCursorHalo) {
        largeCursorHalo = document.createElement('div');
        largeCursorHalo.className = 'access-large-cursor-halo';
        largeCursorHalo.style.left = '-100px';
        largeCursorHalo.style.top = '-100px';
        document.body.appendChild(largeCursorHalo);
    }

    // Clean up any existing handler before creating a new one
    if (largeCursorMoveHandler) {
        document.removeEventListener('mousemove', largeCursorMoveHandler);
    }

    largeCursorMoveHandler = (e) => {
        requestAnimationFrame(() => {
            if (largeCursorDot) {
                largeCursorDot.style.left = e.clientX + 'px';
                largeCursorDot.style.top = e.clientY + 'px';
            }
            if (largeCursorHalo) {
                largeCursorHalo.style.left = e.clientX + 'px';
                largeCursorHalo.style.top = e.clientY + 'px';
            }
        });
    };
    document.addEventListener('mousemove', largeCursorMoveHandler);
    console.log('[SightSync] Large Cursor Mode started');
}

function stopLargeCursor() {
    document.body.classList.remove('access-large-cursor');
    if (largeCursorDot) {
        largeCursorDot.remove();
        largeCursorDot = null;
    }
    if (largeCursorHalo) {
        largeCursorHalo.remove();
        largeCursorHalo = null;
    }
    if (largeCursorMoveHandler) {
        document.removeEventListener('mousemove', largeCursorMoveHandler);
        largeCursorMoveHandler = null;
    }
}

// -----------------------------------
// Magnifier Mode Functions
// -----------------------------------
let magnifierLens = null;
let magnifierClone = null;
let magnifierMoveHandler = null;

function startMagnifier() {
    if (magnifierLens) return;

    magnifierLens = document.createElement('div');
    magnifierLens.className = 'sightsync-magnifier';
    
    magnifierClone = document.body.cloneNode(true);
    
    // Remove scripts and duplicate IDs to prevent issues
    const scripts = magnifierClone.querySelectorAll('script, iframe, video');
    scripts.forEach(s => s.remove());
    
    magnifierClone.className = 'sightsync-magnifier-content';
    magnifierLens.appendChild(magnifierClone);
    document.body.appendChild(magnifierLens);

    magnifierMoveHandler = (e) => {
        requestAnimationFrame(() => {
            if (!magnifierLens || !magnifierClone) return;
            const zoom = 2;
            const lensWidth = 600; // from CSS
            const lensHeight = 400; // from CSS
            
            let x = e.clientX;
            let y = e.clientY;

            // Clamp lens to stay within the viewport
            const minX = lensWidth / 2;
            const maxX = window.innerWidth - (lensWidth / 2);
            const minY = lensHeight / 2;
            const maxY = window.innerHeight - (lensHeight / 2);

            if (x < minX) x = minX;
            if (x > maxX) x = maxX;
            if (y < minY) y = minY;
            if (y > maxY) y = maxY;

            magnifierLens.style.left = x + 'px';
            magnifierLens.style.top = y + 'px';

            const cloneX = e.clientX - x + (lensWidth / 2) - (e.pageX * zoom);
            const cloneY = e.clientY - y + (lensHeight / 2) - (e.pageY * zoom);
            
            magnifierClone.style.transform = `translate(${cloneX}px, ${cloneY}px) scale(${zoom})`;
        });
    };

    document.addEventListener('mousemove', magnifierMoveHandler);
    // Show lens
    magnifierLens.classList.add('active');
    console.log('[SightSync] Magnifier Mode started');
}

function stopMagnifier() {
    if (magnifierMoveHandler) {
        document.removeEventListener('mousemove', magnifierMoveHandler);
        magnifierMoveHandler = null;
    }
    if (magnifierLens) {
        magnifierLens.remove();
        magnifierLens = null;
    }
    magnifierClone = null;
    console.log('[SightSync] Magnifier Mode stopped');
}

// -----------------------------------
// Voice Mode Functions
// -----------------------------------
let currentVoiceElement = null;

function startVoiceMode() {
    console.log("Starting Voice Mode (Cursor Follow)...");
    isVoiceModeEnabled = true;
    
    if (!debouncedMouseMove) {
        debouncedMouseMove = debounce(handleMouseMove, 200);
    }
    window.addEventListener('mousemove', debouncedMouseMove);
}

function stopVoiceMode() {
    console.log("Stopping Voice Mode...");
    isVoiceModeEnabled = false;
    window.speechSynthesis.cancel();
    if (currentVoiceElement) {
        currentVoiceElement.classList.remove('voice-highlight');
        currentVoiceElement = null;
    }
    if (debouncedMouseMove) {
        window.removeEventListener('mousemove', debouncedMouseMove);
    }
}

function handleMouseMove(e) {
    if (!isVoiceModeEnabled) return;

    const element = document.elementFromPoint(e.clientX, e.clientY);
    if (!element) return;

    // Find the closest readable parent if the direct element is not readable
    const readableElement = element.closest('p, h1, h2, h3, h4, h5, h6, li, span, div') || element;
    
    // Validate if it has meaningful text
    const text = readableElement.innerText ? readableElement.innerText.trim() : "";
    if (text.length < 5) return;

    if (readableElement !== currentVoiceElement) {
        readElement(readableElement);
    }
}

function readElement(el) {
    // Stop current speech
    window.speechSynthesis.cancel();
    
    if (currentVoiceElement) {
        currentVoiceElement.classList.remove('voice-highlight');
    }

    currentVoiceElement = el;
    currentVoiceElement.classList.add('voice-highlight');

    const textToRead = el.innerText.trim();
    const utterance = new SpeechSynthesisUtterance(textToRead);
    
    utterance.onend = () => {
        // We keep the highlight while the mouse is over it
    };
    
    window.speechSynthesis.speak(utterance);
}


function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}


// -----------------------------------
// Keyboard Shortcuts for Modes
// -----------------------------------

function toggleModeFromShortcut(modeToToggle) {
    chrome.storage.local.get(currentModes, (result) => {
        const isCurrentlyOn = result[modeToToggle];
        const newStatus = !isCurrentlyOn;
        
        // If turning ON an exclusive mode, turn off all other exclusive modes
        if (newStatus && modeToToggle !== 'largeCursorMode') {
            currentModes.forEach(mode => {
                if (mode !== modeToToggle && mode !== 'largeCursorMode' && result[mode]) {
                    applyMode(mode, false);
                    chrome.storage.local.set({ [mode]: false });
                }
            });
        }
        
        // Toggle the target mode
        applyMode(modeToToggle, newStatus);
        chrome.storage.local.set({ [modeToToggle]: newStatus });
    });
}

function resetAllModesFromShortcut() {
    currentModes.forEach(mode => {
        applyMode(mode, false);
        chrome.storage.local.set({ [mode]: false });
    });
}

document.addEventListener('keydown', (e) => {
    // Check if user is typing in an input field to avoid accidental toggles
    if (e.target && (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName) || e.target.isContentEditable)) {
        return;
    }

    // Check for F1 through F12
    if (e.key.match(/^F([1-9]|1[0-2])$/)) {
        e.preventDefault(); // Prevent default browser actions
        
        if (!isLoggedIn) {
            showLoginModal();
            return;
        }

        switch(e.key) {
            case 'F1': toggleModeFromShortcut('highContrastMode'); break;
            case 'F2': toggleModeFromShortcut('lowVisionMode'); break;
            case 'F3': toggleModeFromShortcut('colorBlindMode'); break;
            case 'F4': toggleModeFromShortcut('tunnelVisionMode'); break;
            case 'F5': toggleModeFromShortcut('peripheralLossMode'); break;
            case 'F6': toggleModeFromShortcut('blurryVisionMode'); break;
            case 'F7': toggleModeFromShortcut('focusMode'); break;
            case 'F8': toggleModeFromShortcut('smartHighlightMode'); break;
            case 'F9': toggleModeFromShortcut('largeCursorMode'); break;
            case 'F10': toggleModeFromShortcut('voiceMode'); break;
            case 'F11': toggleModeFromShortcut('removeImagesMode'); break;
            case 'F12': toggleModeFromShortcut('magnifierMode'); break;
        }
    }
});
