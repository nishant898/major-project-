const modes = [
    'highContrastMode',
    'lowVisionMode',
    'colorBlindMode',
    'tunnelVisionMode',
    'peripheralLossMode',
    'blurryVisionMode',
    'focusMode',
    'smartHighlightMode',
    'largeCursorMode',
    'voiceMode',
    'removeImagesMode',
    'magnifierMode'
];

// --- Elements ---
const mainView = document.getElementById('mainView');
const reviewView = document.getElementById('reviewView');
const loginView = document.getElementById('loginView');

const logoutBtn = document.getElementById('logoutBtn');
const googleLoginBtn = document.getElementById('googleLoginBtn');
const ratingDisplay = document.getElementById('ratingDisplay');

const stars = document.querySelectorAll('.star');
const feedbackInput = document.getElementById('feedbackInput');
const submitReviewBtn = document.getElementById('submitReviewBtn');
const skipReviewBtn = document.getElementById('skipReviewBtn');
const thankYouMsg = document.getElementById('thankYouMsg');
const reviewContainer = document.querySelector('.review-container');

let currentRating = 0;
let lowVisionLevel = 3;
let isLoggingOut = false;

// --- Initialization ---
async function initializeApp() {
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
        showLoginView();
        
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if(tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, { action: "showLoginModal" });
            }
        });
        return;
    }

    showMainView();
    fetchOverallRating();

    chrome.storage.local.get(['lowVisionLevel', ...modes], (result) => {
        if (result.lowVisionLevel) {
            lowVisionLevel = result.lowVisionLevel;
        }
        document.getElementById('lowVisionLevelDisplay').textContent = lowVisionLevel;

        // Initialize mode toggles
        modes.forEach(mode => {
            if (result[mode]) {
                document.getElementById(mode).checked = true;
                if (mode === 'lowVisionMode') {
                    document.getElementById('lowVisionControls').classList.remove('hidden');
                }
            }
        });
    });
}

initializeApp();

// --- View Switching ---
function showMainView() {
    mainView.classList.remove('hidden');
    reviewView.classList.add('hidden');
    loginView.classList.add('hidden');
}

function showReviewView() {
    reviewView.classList.remove('hidden');
    mainView.classList.add('hidden');
    loginView.classList.add('hidden');
    
    // Reset review form
    currentRating = 0;
    updateStars(0);
    feedbackInput.value = '';
    reviewContainer.classList.remove('hidden');
    thankYouMsg.classList.add('hidden');
}

function showLoginView() {
    loginView.classList.remove('hidden');
    mainView.classList.add('hidden');
    reviewView.classList.add('hidden');
}

// --- Auth Logic ---
googleLoginBtn.addEventListener('click', async () => {
    try {
        const { data, error } = await supabase.auth.signInWithOAuth({
            provider: 'google',
            options: {
                redirectTo: chrome.identity.getRedirectURL(),
                skipBrowserRedirect: true
            }
        });
        if (error) throw error;

        // Launch Web Auth Flow
        chrome.identity.launchWebAuthFlow({
            url: data.url,
            interactive: true
        }, async (redirectUrl) => {
            if (chrome.runtime.lastError) {
                console.error(chrome.runtime.lastError);
                return;
            }

            // Extract code or token from redirect URL
            const url = new URL(redirectUrl);
            const params = new URLSearchParams(url.search);
            const code = params.get('code');
            
            if (code) {
                await supabase.auth.exchangeCodeForSession(code);
            } else {
                const hashParams = new URLSearchParams(url.hash.replace('#', ''));
                const access_token = hashParams.get('access_token');
                const refresh_token = hashParams.get('refresh_token');
                if (access_token && refresh_token) {
                    await supabase.auth.setSession({ access_token, refresh_token });
                }
            }

            // Notify content script
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                if(tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, { action: "loginSuccess" });
                }
            });

            showMainView();
            fetchOverallRating();
        });

    } catch (error) {
        console.error("Login error:", error);
    }
});

logoutBtn.addEventListener('click', async () => {
    // Stop the extension by resetting all active modes when logging out
    modes.forEach(m => {
        document.getElementById(m).checked = false;
        chrome.storage.local.set({ [m]: false });
    });
    
    // Notify active tab to turn off all features
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if(tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, { action: "resetAllModes" });
        }
    });

    await supabase.auth.signOut();
    isLoggingOut = true;
    showReviewView();
});

// --- Mode Logic ---
modes.forEach(mode => {
    document.getElementById(mode).addEventListener('change', (e) => {
        const isChecked = e.target.checked;
        console.log(`[SightSync Popup] Toggling ${mode} to ${isChecked}`);
        
        // Exclusive Mode Logic: If turning ON a mode that isn't Large Cursor, disable other exclusive modes
        if (isChecked && mode !== 'largeCursorMode') {
            modes.forEach(m => {
                if (m !== mode && m !== 'largeCursorMode') {
                    const checkbox = document.getElementById(m);
                    if (checkbox.checked) {
                        checkbox.checked = false;
                        chrome.storage.local.set({ [m]: false });
                        if (m === 'lowVisionMode') {
                            document.getElementById('lowVisionControls').classList.add('hidden');
                        }
                        
                        // Tell content script to disable this mode
                        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                            if(tabs[0]) {
                                chrome.tabs.sendMessage(tabs[0].id, {
                                    action: "toggleMode",
                                    mode: m,
                                    value: false
                                });
                            }
                        });
                    }
                }
            });
        }

        // Show/hide low vision controls
        if (mode === 'lowVisionMode') {
            if (isChecked) {
                document.getElementById('lowVisionControls').classList.remove('hidden');
            } else {
                document.getElementById('lowVisionControls').classList.add('hidden');
            }
        }

        // Save to storage
        chrome.storage.local.set({ [mode]: isChecked });
        
        // Notify active tab content script — only toggle this specific mode
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if(tabs[0]) {
                console.log(`[SightSync Popup] Sending to tab ${tabs[0].id}: mode=${mode}, value=${isChecked}`);
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: "toggleMode",
                    mode: mode,
                    value: isChecked
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        console.warn('[SightSync Popup] Message failed:', chrome.runtime.lastError.message);
                    } else {
                        console.log('[SightSync Popup] Content script responded:', response);
                    }
                });
            }
        });
    });
});

// Reset all
document.getElementById('resetBtn').addEventListener('click', () => {
    let wasAnyModeOn = false;
    
    modes.forEach(mode => {
        const checkbox = document.getElementById(mode);
        if (checkbox.checked) {
            wasAnyModeOn = true;
        }
        checkbox.checked = false;
        chrome.storage.local.set({ [mode]: false });
        if (mode === 'lowVisionMode') {
            document.getElementById('lowVisionControls').classList.add('hidden');
        }
    });
    
    // Notify active tab
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if(tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: "resetAllModes"
            });
        }
    });
});

// Listen for storage changes from the content script (keyboard shortcuts)
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local') {
        for (let [key, { oldValue, newValue }] of Object.entries(changes)) {
            if (modes.includes(key)) {
                const checkbox = document.getElementById(key);
                if (checkbox && checkbox.checked !== newValue) {
                    checkbox.checked = newValue;
                    if (key === 'lowVisionMode') {
                        const controls = document.getElementById('lowVisionControls');
                        if (newValue) controls.classList.remove('hidden');
                        else controls.classList.add('hidden');
                    }
                }
            }
        }
    }
});

// Keyboard shortcuts while popup is open
document.addEventListener('keydown', (e) => {
    // Only allow shortcuts if logged in and on main view
    if (!mainView.classList.contains('hidden')) {
        if (e.key.match(/^F([1-9]|1[0-2])$/)) {
            e.preventDefault();
            let modeId = '';
            switch(e.key) {
                case 'F1': modeId = 'highContrastMode'; break;
                case 'F2': modeId = 'lowVisionMode'; break;
                case 'F3': modeId = 'colorBlindMode'; break;
                case 'F4': modeId = 'tunnelVisionMode'; break;
                case 'F5': modeId = 'peripheralLossMode'; break;
                case 'F6': modeId = 'blurryVisionMode'; break;
                case 'F7': modeId = 'focusMode'; break;
                case 'F8': modeId = 'smartHighlightMode'; break;
                case 'F9': modeId = 'largeCursorMode'; break;
                case 'F10': modeId = 'voiceMode'; break;
                case 'F11': modeId = 'removeImagesMode'; break;
                case 'F12': modeId = 'magnifierMode'; break;
            }
            if (modeId) {
                const checkbox = document.getElementById(modeId);
                if (checkbox) {
                    checkbox.click();
                }
            }
        }
    }
});

// --- Review Logic ---
function updateStars(rating) {
    stars.forEach(star => {
        const val = parseInt(star.getAttribute('data-value'));
        if (val <= rating) {
            star.classList.add('active');
        } else {
            star.classList.remove('active');
        }
    });
}

stars.forEach(star => {
    star.addEventListener('click', (e) => {
        currentRating = parseInt(e.target.getAttribute('data-value'));
        updateStars(currentRating);
    });
});

submitReviewBtn.addEventListener('click', async () => {
    if (currentRating > 0) {
        const feedback = feedbackInput.value;
        
        try {
            const { data: { session } } = await supabase.auth.getSession();
            if (session) {
                await supabase.from('reviews').insert({
                    user_id: session.user.id,
                    rating: currentRating,
                    feedback: feedback
                });
            }
        } catch (e) {
            console.error("Error saving review", e);
        }

        // Show thank you message
        reviewContainer.classList.add('hidden');
        thankYouMsg.classList.remove('hidden');

        setTimeout(() => {
            if (isLoggingOut) {
                window.close();
            } else {
                showMainView();
                fetchOverallRating();
            }
        }, 1500);
    } else {
        alert("Please select a star rating before submitting.");
    }
});

skipReviewBtn.addEventListener('click', () => {
    if (isLoggingOut) {
        window.close();
    } else {
        showMainView();
    }
});

// --- Low Vision Controls ---
document.getElementById('decreaseLowVision').addEventListener('click', (e) => {
    e.stopPropagation();
    if (lowVisionLevel > 1) {
        lowVisionLevel--;
        updateLowVisionLevel(lowVisionLevel);
    }
});

document.getElementById('increaseLowVision').addEventListener('click', (e) => {
    e.stopPropagation();
    if (lowVisionLevel < 5) {
        lowVisionLevel++;
        updateLowVisionLevel(lowVisionLevel);
    }
});

function updateLowVisionLevel(level) {
    document.getElementById('lowVisionLevelDisplay').textContent = level;
    chrome.storage.local.set({ lowVisionLevel: level });
    
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if(tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: "updateLowVisionLevel",
                level: level
            });
        }
    });
}

// --- Ratings Display ---
async function fetchOverallRating() {
    try {
        const { data, error } = await supabase.from('reviews').select('rating');
        if (error) throw error;

        if (data && data.length > 0) {
            const total = data.length;
            const sum = data.reduce((acc, curr) => acc + curr.rating, 0);
            const avg = (sum / total).toFixed(1);
            
            ratingDisplay.innerText = `⭐ ${avg} / 5 Based on ${total} reviews`;
        } else {
            ratingDisplay.innerText = `⭐ -- / 5 No reviews yet`;
        }
    } catch (e) {
        console.error("Error fetching rating:", e);
        ratingDisplay.innerText = `⭐ -- / 5`;
    }
}
