// Background service worker
try {
  importScripts('../supabase-js.js', '../popup/supabaseClient.js');
} catch (e) {
  console.error("Failed to load scripts in background:", e);
}

chrome.runtime.onInstalled.addListener(() => {
  console.log('SightSync extension installed.');
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'startGoogleAuth') {
        (async () => {
            try {
                const { data, error } = await supabase.auth.signInWithOAuth({
                    provider: 'google',
                    options: {
                        redirectTo: chrome.identity.getRedirectURL(),
                        skipBrowserRedirect: true
                    }
                });
                if (error) throw error;

                chrome.identity.launchWebAuthFlow({
                    url: data.url,
                    interactive: true
                }, async (redirectUrl) => {
                    if (chrome.runtime.lastError) {
                        sendResponse({ success: false, error: chrome.runtime.lastError.message });
                        return;
                    }

                    const url = new URL(redirectUrl);
                    const params = new URLSearchParams(url.search);
                    const code = params.get('code');
                    
                    if (code) {
                        await supabase.auth.exchangeCodeForSession(code);
                    } else {
                        const hashParams = new URLSearchParams(url.hash.replace('#', ''));
                        const access_token = hashParams.get('access_token');
                        const refresh_token = hashParams.get('refresh_token');
                        if (access_token && refresh_token) {
                            await supabase.auth.setSession({ access_token, refresh_token });
                        }
                    }

                    // Tell the content script that login was successful
                    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                        if(tabs && tabs[0]) {
                            chrome.tabs.sendMessage(tabs[0].id, { action: "loginSuccess" });
                        }
                    });

                    sendResponse({ success: true });
                });
            } catch (err) {
                console.error("Background auth error:", err);
                sendResponse({ success: false, error: err.message });
            }
        })();
        return true; // Keep channel open for async response
    }
});
