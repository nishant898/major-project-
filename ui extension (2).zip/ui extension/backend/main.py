from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from services.openai_service import simplify_text
import uvicorn

app = FastAPI(title="Accessible AI UI Transformer API")

# Configure CORS so the Chrome Extension can make requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # In production, restrict this
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class TextPayload(BaseModel):
    text: str

@app.get("/")
def read_root():
    return {"status": "ok", "message": "Accessible AI UI Transformer Backend Running"}

@app.post("/api/simplify")
async def api_simplify_text(payload: TextPayload):
    try:
        if not payload.text or len(payload.text.strip()) == 0:
            raise HTTPException(status_code=400, detail="Text cannot be empty")
        
        simplified = await simplify_text(payload.text)
        return {"original": payload.text, "simplified": simplified}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
