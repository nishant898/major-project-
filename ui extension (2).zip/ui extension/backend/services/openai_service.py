import os
from openai import AsyncOpenAI
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# Initialize OpenAI Client if key exists and is not a placeholder
is_placeholder = OPENAI_API_KEY.startswith("sk-ijkl") or OPENAI_API_KEY == "your_openai_api_key_here"

is_openrouter = OPENAI_API_KEY.startswith("sk-or-")
base_url = "https://openrouter.ai/api/v1" if is_openrouter else None

client = AsyncOpenAI(api_key=OPENAI_API_KEY, base_url=base_url) if (OPENAI_API_KEY and not is_placeholder) else None

async def simplify_text(text: str) -> str:
    """
    Summarizes and simplifies complex text to make it cognitively accessible.
    """
    if not client:
        return "[OpenAI API Key missing. Skipping simplification for accessibility mode.]"

    try:
        prompt = f"""
You are an expert accessibility assistant. Simplify the following text for a user needing cognitive accessibility. 
Make it easy to read, summarize complex points, and convert into simple bullet points if necessary.

Text to simplify:
{text}
"""
        model_name = "openai/gpt-4o-mini" if is_openrouter else "gpt-4o-mini"
        response = await client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": "You are a helpful accessibility assistant."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=500,
            temperature=0.3
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"Error calling OpenAI API: {e}")
        return "[Error generating simplified text.]"
