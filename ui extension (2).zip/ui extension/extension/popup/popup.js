document.addEventListener('DOMContentLoaded', () => {
    const toolbarToggle = document.getElementById('toolbarToggle');
    const themeToggle = document.getElementById('themeToggle');
    const logoutBtn = document.getElementById('logoutBtn');
    const mainView = document.getElementById('mainView');
    const reviewView = document.getElementById('reviewView');
    const stars = document.querySelectorAll('.star');

    chrome.storage.local.get(['toolbarEnabled', 'toolbarTheme'], (result) => {
        if (result.toolbarEnabled !== undefined) {
            toolbarToggle.checked = result.toolbarEnabled;
        } else {
            toolbarToggle.checked = true; 
        }

        if (result.toolbarTheme === 'light') {
            themeToggle.checked = true;
        } else {
            themeToggle.checked = false;
        }
    });

    toolbarToggle.addEventListener('change', (e) => {
        const isEnabled = e.target.checked;
        chrome.storage.local.set({ toolbarEnabled: isEnabled });
        
        chrome.tabs.query({ active: true, currentWindow: true }, function (activeTabs) {
            const activeTabId = activeTabs[0] ? activeTabs[0].id : null;
            chrome.tabs.query({}, function (tabs) {
                for (let tab of tabs) {
                    try {
                        const showReview = (tab.id === activeTabId) && !isEnabled;
                        chrome.tabs.sendMessage(tab.id, { action: "toggleToolbar", value: isEnabled, showReview: showReview }, () => {
                            if (chrome.runtime.lastError) {
                                // Ignore errors for tabs without content script
                            }
                        });
                    } catch (err) {}
                }
            });
        });
    });

    themeToggle.addEventListener('change', (e) => {
        const isLight = e.target.checked;
        const theme = isLight ? 'light' : 'dark';
        chrome.storage.local.set({ toolbarTheme: theme });
        
        chrome.tabs.query({}, function (tabs) {
            for (let tab of tabs) {
                try {
                    chrome.tabs.sendMessage(tab.id, { action: "toggleTheme", value: theme }, () => {
                        if (chrome.runtime.lastError) {}
                    });
                } catch (err) {}
            }
        });
    });

    logoutBtn.addEventListener('click', () => {
        chrome.storage.local.set({ isLoggedIn: false });
        mainView.innerHTML = `
            <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; padding: 32px 24px;">
                <h2 style="margin: 0; margin-bottom: 8px;">Logged Out</h2>
                <p style="color: var(--text-secondary); font-size: 0.9rem;">You have successfully logged out.</p>
            </div>
        `;
    });
});
