// extension/popup/supabaseClient.js

// Replace these with your actual Supabase Project URL and Anon Key
const SUPABASE_URL = 'https://cdusyzfkvlvbgqtwlzan.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNkdXN5emZrdmx2YmdxdHdsemFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzc5ODkzNTQsImV4cCI6MjA5MzU2NTM1NH0.jVbovKKzNTykG5O9m0gJVmz6HUUNKKFxbo3dTN3e3n4';

// Custom storage adapter using chrome.storage.local for Manifest V3 persistence
const chromeStorageAdapter = {
  getItem: (key) => {
    return new Promise((resolve) => {
      chrome.storage.local.get([key], (result) => {
        resolve(result[key]);
      });
    });
  },
  setItem: (key, value) => {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [key]: value }, () => {
        resolve();
      });
    });
  },
  removeItem: (key) => {
    return new Promise((resolve) => {
      chrome.storage.local.remove([key], () => {
        resolve();
      });
    });
  }
};

const globalObj = typeof window !== 'undefined' ? window : self;
const supabase = globalObj.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: chromeStorageAdapter,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false
  }
});
