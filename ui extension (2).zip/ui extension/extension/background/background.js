// Background service worker
try {
  importScripts('../supabase-js.js', '../popup/supabaseClient.js');
} catch (e) {
  console.error("Failed to load scripts in background:", e);
}

chrome.runtime.onInstalled.addListener(() => {
  console.log('SightSync extension installed.');
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'startGoogleAuth') {
        (async () => {
            try {
                const { data, error } = await supabase.auth.signInWithOAuth({
                    provider: 'google',
                    options: {
                        redirectTo: chrome.identity.getRedirectURL(),
                        skipBrowserRedirect: true
                    }
                });
                if (error) throw error;

                chrome.identity.launchWebAuthFlow({
                    url: data.url,
                    interactive: true
                }, async (redirectUrl) => {
                    if (chrome.runtime.lastError) {
                        sendResponse({ success: false, error: chrome.runtime.lastError.message });
                        return;
                    }

                    const url = new URL(redirectUrl);
                    const params = new URLSearchParams(url.search);
                    const code = params.get('code');
                    
                    if (code) {
                        await supabase.auth.exchangeCodeForSession(code);
                    } else {
                        const hashParams = new URLSearchParams(url.hash.replace('#', ''));
                        const access_token = hashParams.get('access_token');
                        const refresh_token = hashParams.get('refresh_token');
                        if (access_token && refresh_token) {
                            await supabase.auth.setSession({ access_token, refresh_token });
                        }
                    }

                    // Save login state in local storage for easy sync
                    await chrome.storage.local.set({ isLoggedIn: true });

                    // Tell the content script that login was successful
                    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                        if(tabs && tabs[0]) {
                            chrome.tabs.sendMessage(tabs[0].id, { action: "loginSuccess" });
                        }
                    });

                    sendResponse({ success: true });
                });
            } catch (err) {
                console.error("Background auth error:", err);
                sendResponse({ success: false, error: err.message });
            }
        })();
        return true; // Keep channel open for async response
    }
    
    if (request.action === 'getSession') {
        supabase.auth.getSession().then(({ data }) => {
            sendResponse({ session: data.session });
        }).catch(err => {
            sendResponse({ error: err.message });
        });
        return true;
    }

    if (request.action === 'logout') {
        (async () => {
            await supabase.auth.signOut();
            await chrome.storage.local.set({ isLoggedIn: false });
            sendResponse({ success: true });
        })();
        return true;
    }

    if (request.action === 'submitReview') {
        (async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession();
                if (session) {
                    await supabase.from('reviews').insert({
                        user_id: session.user.id,
                        rating: request.rating,
                        feedback: request.feedback
                    });
                    sendResponse({ success: true });
                } else {
                    sendResponse({ success: false, error: 'No active session' });
                }
            } catch (err) {
                console.error("Error saving review", err);
                sendResponse({ success: false, error: err.message });
            }
        })();
        return true;
    }

    if (request.action === 'fetchOverallRating') {
        (async () => {
            try {
                const { data, error } = await supabase.from('reviews').select('rating');
                if (error) throw error;
                if (data && data.length > 0) {
                    const total = data.length;
                    const sum = data.reduce((acc, curr) => acc + curr.rating, 0);
                    const avg = (sum / total).toFixed(1);
                    sendResponse({ success: true, avg, total });
                } else {
                    sendResponse({ success: true, avg: '--', total: 0 });
                }
            } catch (err) {
                console.error("Error fetching rating:", err);
                sendResponse({ success: false, error: err.message });
            }
        })();
        return true;
    }
});
