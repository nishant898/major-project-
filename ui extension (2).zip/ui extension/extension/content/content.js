// Content script runs on the active webpage

const currentModes = [
    'highContrastMode', 'lowVisionMode', 'colorBlindMode',
    'tunnelVisionMode', 'peripheralLossMode', 'blurryVisionMode',
    'focusMode', 'smartHighlightMode', 'largeCursorMode', 'voiceMode',
    'removeImagesMode', 'magnifierMode'
];

const modeLabels = {
    highContrastMode: { label: 'High Contrast', tooltip: 'High Contrast (F1)' },
    lowVisionMode: { label: 'Low Vision', tooltip: 'Low Vision (F2)' },
    colorBlindMode: { label: 'Color Blind', tooltip: 'Color Blind (F3)' },
    tunnelVisionMode: { label: 'Tunnel Vision', tooltip: 'Tunnel Vision (F4)' },
    peripheralLossMode: { label: 'Peripheral Vision', tooltip: 'Peripheral Vision (F5)' },
    blurryVisionMode: { label: 'Blurry Vision', tooltip: 'Blurry Vision (F6)' },
    focusMode: { label: 'Focus Mode', tooltip: 'Focus Mode (F7)' },
    smartHighlightMode: { label: 'Smart Highlight', tooltip: 'Smart Highlight (F8)' },
    largeCursorMode: { label: 'Large Cursor', tooltip: 'Large Cursor (F9)' },
    voiceMode: { label: 'Voice Mode', tooltip: 'Voice Mode (F10)' },
    removeImagesMode: { label: 'Remove Images', tooltip: 'Remove Images (F11)' },
    magnifierMode: { label: 'Magnifier', tooltip: 'Magnifier Mode (F12)' }
};

let isLoggedIn = false;
let currentRating = 0;

function createToolbar() {
    if (document.getElementById('sightsync-toolbar')) return;

    const toolbar = document.createElement('div');
    toolbar.id = 'sightsync-toolbar';

    const brand = document.createElement('div');
    brand.className = 'sightsync-toolbar-brand';
    brand.innerText = 'SightSync';
    toolbar.appendChild(brand);

    currentModes.forEach(mode => {
        const btn = document.createElement('button');
        btn.className = 'sightsync-toolbar-btn';
        btn.id = `ss-btn-${mode}`;
        btn.innerText = modeLabels[mode].label;
        btn.title = modeLabels[mode].tooltip;

        btn.addEventListener('click', () => {
            if (!isLoggedIn) {
                showLoginModal();
                return;
            }
            toggleMode(mode);
        });

        toolbar.appendChild(btn);
    });

    const divider = document.createElement('div');
    divider.className = 'sightsync-toolbar-divider';
    toolbar.appendChild(divider);

    const lvControls = document.createElement('div');
    lvControls.id = 'sightsync-lv-controls';
    lvControls.className = 'sightsync-lv-controls sightsync-hidden';
    
    const decBtn = document.createElement('button');
    decBtn.innerText = '-';
    decBtn.className = 'sightsync-toolbar-btn lv-btn';
    
    const lvlDisplay = document.createElement('span');
    lvlDisplay.id = 'sightsync-lv-level';
    lvlDisplay.className = 'sightsync-lv-level';
    lvlDisplay.innerText = '3';
    
    const incBtn = document.createElement('button');
    incBtn.innerText = '+';
    incBtn.className = 'sightsync-toolbar-btn lv-btn';

    decBtn.addEventListener('click', () => {
        chrome.storage.local.get(['lowVisionLevel'], (res) => {
            let level = res.lowVisionLevel || 3;
            if (level > 1) {
                level--;
                chrome.storage.local.set({ lowVisionLevel: level });
                updateLowVisionSize(level);
                lvlDisplay.innerText = level;
            }
        });
    });

    incBtn.addEventListener('click', () => {
        chrome.storage.local.get(['lowVisionLevel'], (res) => {
            let level = res.lowVisionLevel || 3;
            if (level < 5) {
                level++;
                chrome.storage.local.set({ lowVisionLevel: level });
                updateLowVisionSize(level);
                lvlDisplay.innerText = level;
            }
        });
    });

    lvControls.appendChild(decBtn);
    lvControls.appendChild(lvlDisplay);
    lvControls.appendChild(incBtn);
    toolbar.appendChild(lvControls);

    const infoBtn = document.createElement('button');
    infoBtn.className = 'sightsync-toolbar-btn';
    infoBtn.id = 'ss-btn-info';
    infoBtn.innerText = 'ⓘ';
    infoBtn.title = 'About SightSync';
    
    infoBtn.addEventListener('click', () => {
        showInfoModal();
    });
    toolbar.appendChild(infoBtn);

    document.documentElement.appendChild(toolbar);
}

function updateToolbarUI(mode, isActive) {
    const btn = document.getElementById(`ss-btn-${mode}`);
    if (btn) {
        if (isActive) btn.classList.add('active');
        else btn.classList.remove('active');
    }
    
    if (mode === 'lowVisionMode') {
        const lvControls = document.getElementById('sightsync-lv-controls');
        if (lvControls) {
            if (isActive) lvControls.classList.remove('sightsync-hidden');
            else lvControls.classList.add('sightsync-hidden');
        }
    }

    const toolbar = document.getElementById('sightsync-toolbar');
    if (toolbar) {
        if (mode === 'highContrastMode') {
            if (isActive) toolbar.classList.add('sightsync-hc');
            else toolbar.classList.remove('sightsync-hc');
        }
        if (mode === 'colorBlindMode') {
            if (isActive) toolbar.classList.add('sightsync-cb');
            else toolbar.classList.remove('sightsync-cb');
        }
    }
}

function toggleMode(modeToToggle) {
    chrome.storage.local.get(currentModes, (result) => {
        const isCurrentlyOn = result[modeToToggle];
        const newStatus = !isCurrentlyOn;
        
        // If turning ON an exclusive mode, turn off all other exclusive modes
        if (newStatus && modeToToggle !== 'largeCursorMode') {
            currentModes.forEach(mode => {
                if (mode !== modeToToggle && mode !== 'largeCursorMode' && result[mode]) {
                    applyMode(mode, false);
                    updateToolbarUI(mode, false);
                    chrome.storage.local.set({ [mode]: false });
                }
            });
        }
        
        // Toggle the target mode
        applyMode(modeToToggle, newStatus);
        updateToolbarUI(modeToToggle, newStatus);
        chrome.storage.local.set({ [modeToToggle]: newStatus });
    });
}

function initializeModes() {
    if (!document.body) {
        setTimeout(initializeModes, 50);
        return;
    }

    createToolbar();

    chrome.storage.local.get([...currentModes, 'lowVisionLevel', 'isLoggedIn', 'toolbarEnabled', 'toolbarTheme'], (result) => {
        isLoggedIn = !!result.isLoggedIn;

        const toolbar = document.getElementById('sightsync-toolbar');
        if (toolbar) {
            if (result.toolbarEnabled === false) {
                toolbar.style.display = 'none';
            } else {
                toolbar.style.display = 'flex';
            }

            if (result.toolbarTheme === 'light') {
                toolbar.classList.add('sightsync-light-theme');
            } else {
                toolbar.classList.remove('sightsync-light-theme');
            }
        }

        if (result.lowVisionLevel) {
            updateLowVisionSize(result.lowVisionLevel);
            const lvLevelDisplay = document.getElementById('sightsync-lv-level');
            if (lvLevelDisplay) lvLevelDisplay.innerText = result.lowVisionLevel;
        } else {
            updateLowVisionSize(3); // Default
        }

        Object.keys(result).forEach(mode => {
            if (currentModes.includes(mode) && result[mode]) {
                applyMode(mode, true);
                updateToolbarUI(mode, true);
                if (mode === 'voiceMode') isVoiceModeEnabled = true;
            }
        });
    });
}

initializeModes();
  
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "toggleMode") {
        applyMode(request.mode, request.value);
        updateToolbarUI(request.mode, request.value);
    } else if (request.action === "resetAllModes") {
        currentModes.forEach(mode => {
            applyMode(mode, false);
            updateToolbarUI(mode, false);
        });
    } else if (request.action === "updateLowVisionLevel") {
        updateLowVisionSize(request.level);
    } else if (request.action === "showLoginModal") {
        showLoginModal();
    } else if (request.action === "loginSuccess") {
        isLoggedIn = true;
        const overlay = document.getElementById('sightsync-login-overlay');
        if (overlay) overlay.remove();
    } else if (request.action === "toggleToolbar") {
        const toolbar = document.getElementById('sightsync-toolbar');
        if (toolbar) {
            toolbar.style.display = request.value ? 'flex' : 'none';
        }
        if (request.showReview) {
            showReviewModal();
        }
    } else if (request.action === "toggleTheme") {
        const toolbar = document.getElementById('sightsync-toolbar');
        if (toolbar) {
            if (request.value === 'light') {
                toolbar.classList.add('sightsync-light-theme');
            } else {
                toolbar.classList.remove('sightsync-light-theme');
            }
        }
    }
    sendResponse({ received: true });
    return true;
});

function showLoginModal() {
    if (document.getElementById('sightsync-login-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'sightsync-login-overlay';
    overlay.className = 'sightsync-modal-overlay';
    
    overlay.innerHTML = `
        <div class="sightsync-login-modal" id="sightsync-login-modal">
            <button class="sightsync-close-btn" id="sightsync-close-modal">×</button>
            <div class="sightsync-login-header">
                <h1>SightSync</h1>
                <p>Login to access features</p>
            </div>
            <button id="ssGoogleLoginBtn" class="sightsync-btn sightsync-btn-primary" style="display: flex; align-items: center; justify-content: center; gap: 10px;">
                <svg width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
                Sign in with Google
            </button>
        </div>
    `;
    
    document.documentElement.appendChild(overlay);

    document.getElementById('sightsync-close-modal').addEventListener('click', () => {
        overlay.remove();
    });

    document.getElementById('ssGoogleLoginBtn').addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: "startGoogleAuth" }, (response) => {
            if (response && response.success) {
                isLoggedIn = true;
                overlay.remove();
            } else {
                console.error("Login failed:", response?.error);
            }
        });
    });
    
    document.getElementById('sightsync-login-modal').addEventListener('click', (e) => {
        e.stopPropagation();
    });
}

function showInfoModal() {
    if (document.getElementById('sightsync-info-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'sightsync-info-overlay';
    overlay.className = 'sightsync-modal-overlay';

    overlay.innerHTML = `
        <div class="sightsync-info-modal" id="sightsync-info-modal">
            <button class="sightsync-close-btn" id="sightsync-close-info">×</button>
            <h2>Accessibility Guide</h2>
            <div class="sightsync-info-content">
                <div class="sightsync-info-item"><strong>[HC] High Contrast (F1):</strong> Maximum readability for Low Contrast Sensitivity.</div>
                <div class="sightsync-info-item"><strong>[LV] Low Vision (F2):</strong> Larger text & elements for Macular Degeneration.</div>
                <div class="sightsync-info-item"><strong>[CB] Color Blind (F3):</strong> Optimized palette for Color Vision Deficiency.</div>
                <div class="sightsync-info-item"><strong>[TV] Tunnel Vision (F4):</strong> Center-focused layout for Glaucoma.</div>
                <div class="sightsync-info-item"><strong>[PV] Peripheral Vision (F5):</strong> Edge-focused layout for Central Vision Loss.</div>
                <div class="sightsync-info-item"><strong>[BV] Blurry Vision (F6):</strong> Sharpened visual elements for Cataracts.</div>
                <div class="sightsync-info-item"><strong>[FM] Focus Mode (F7):</strong> Distraction-free reading. Hides ads.</div>
                <div class="sightsync-info-item"><strong>[SH] Smart Highlight (F8):</strong> Glow on interactive elements for Navigation.</div>
                <div class="sightsync-info-item"><strong>[LC] Large Cursor (F9):</strong> Enhanced pointer visibility.</div>
                <div class="sightsync-info-item"><strong>[VM] Voice Mode (F10):</strong> Reads content aloud for Total Blindness.</div>
                <div class="sightsync-info-item"><strong>[RM] Remove Images (F11):</strong> Hides all images for cognitive focus.</div>
                <div class="sightsync-info-item"><strong>[MG] Magnifier (F12):</strong> Zoom lens under cursor for Precision Reading.</div>
            </div>
        </div>
    `;

    document.documentElement.appendChild(overlay);

    document.getElementById('sightsync-close-info').addEventListener('click', () => {
        overlay.remove();
    });

    document.getElementById('sightsync-info-modal').addEventListener('click', (e) => {
        e.stopPropagation();
    });
}

function showReviewModal() {
    if (document.getElementById('sightsync-review-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'sightsync-review-overlay';
    overlay.className = 'sightsync-modal-overlay';
    
    currentRating = 0;

    overlay.innerHTML = `
        <div class="sightsync-review-modal" id="sightsync-review-modal">
            <button class="sightsync-close-btn" id="sightsync-close-review">×</button>
            <h2>Rate your experience</h2>
            <div class="sightsync-review-stats" id="sightsync-review-stats">Loading reviews...</div>
            <p>How was your experience using this accessibility mode?</p>
            
            <div class="sightsync-star-rating">
                <span class="sightsync-star" data-value="5">★</span>
                <span class="sightsync-star" data-value="4">★</span>
                <span class="sightsync-star" data-value="3">★</span>
                <span class="sightsync-star" data-value="2">★</span>
                <span class="sightsync-star" data-value="1">★</span>
            </div>

            <div class="sightsync-form-group">
                <textarea id="sightsync-feedback" rows="3" placeholder="Tell us what you liked or how we can improve..."></textarea>
            </div>

            <button id="sightsync-submit-review" class="sightsync-btn sightsync-btn-primary">Submit Rating</button>
            <button id="sightsync-skip-review" class="sightsync-btn sightsync-btn-secondary">Skip</button>
            
            <div id="sightsync-review-success" class="sightsync-success-msg hidden">
                <div class="sightsync-success-icon">✓</div>
                <p>Thank you for your feedback!</p>
            </div>
        </div>
    `;
    
    document.documentElement.appendChild(overlay);

    chrome.runtime.sendMessage({ action: "fetchOverallRating" }, (response) => {
        const statsEl = document.getElementById('sightsync-review-stats');
        if (response && response.success && statsEl) {
            statsEl.innerText = `⭐ ${response.avg} / 5 Based on ${response.total} reviews`;
        } else if (statsEl) {
            statsEl.innerText = `⭐ -- / 5 No reviews yet`;
        }
    });

    const stars = overlay.querySelectorAll('.sightsync-star');
    stars.forEach(star => {
        star.addEventListener('click', (e) => {
            currentRating = parseInt(e.target.getAttribute('data-value'));
            stars.forEach(s => {
                if (parseInt(s.getAttribute('data-value')) <= currentRating) {
                    s.classList.add('active');
                } else {
                    s.classList.remove('active');
                }
            });
        });
    });

    document.getElementById('sightsync-close-review').addEventListener('click', () => overlay.remove());
    document.getElementById('sightsync-skip-review').addEventListener('click', () => overlay.remove());

    document.getElementById('sightsync-submit-review').addEventListener('click', () => {
        if (currentRating === 0) {
            alert('Please select a star rating.');
            return;
        }
        const feedback = document.getElementById('sightsync-feedback').value;
        
        chrome.runtime.sendMessage({ action: "submitReview", rating: currentRating, feedback }, (res) => {
            if(res && res.success) {
                document.getElementById('sightsync-review-success').classList.remove('hidden');
                document.getElementById('sightsync-submit-review').style.display = 'none';
                document.getElementById('sightsync-skip-review').style.display = 'none';
                setTimeout(() => {
                    overlay.remove();
                }, 1500);
            } else {
                alert('Error submitting review.');
            }
        });
    });

    document.getElementById('sightsync-review-modal').addEventListener('click', (e) => e.stopPropagation());
}


function updateLowVisionSize(level) {
    const size = 40 + (level * 10);
    document.documentElement.style.setProperty('--low-vision-size', `${size}px`, 'important');
}

let tunnelOverlay = null;
let isVoiceModeEnabled = false;
let debouncedMouseMove = null;

function applyMode(mode, enable) {
    const body = document.body;
    switch(mode) {
        case 'highContrastMode':
            enable ? body.classList.add('access-high-contrast') : body.classList.remove('access-high-contrast');
            break;

        case 'lowVisionMode':
            enable ? body.classList.add('access-low-vision') : body.classList.remove('access-low-vision');
            break;

        case 'colorBlindMode':
            enable ? body.classList.add('access-color-blind') : body.classList.remove('access-color-blind');
            break;

        case 'tunnelVisionMode':
            if (enable) {
                if(!tunnelOverlay) {
                    tunnelOverlay = document.createElement('div');
                    tunnelOverlay.className = 'access-tunnel-overlay';
                    document.documentElement.appendChild(tunnelOverlay);
                    
                    document.addEventListener('mousemove', moveTunnel);
                }
            } else {
                if(tunnelOverlay) {
                    document.removeEventListener('mousemove', moveTunnel);
                    tunnelOverlay.remove();
                    tunnelOverlay = null;
                }
            }
            break;

        case 'peripheralLossMode':
            enable ? body.classList.add('access-peripheral') : body.classList.remove('access-peripheral');
            break;

        case 'blurryVisionMode':
            enable ? body.classList.add('access-blurry-vision') : body.classList.remove('access-blurry-vision');
            break;

        case 'focusMode':
            if (enable) {
                body.classList.add('access-focus');
                applyFocusModeEnhancements();
            } else {
                body.classList.remove('access-focus');
                removeFocusModeEnhancements();
            }
            break;

        case 'smartHighlightMode':
            enable ? body.classList.add('access-smart-highlight') : body.classList.remove('access-smart-highlight');
            break;

        case 'largeCursorMode':
            if (enable) startLargeCursor();
            else stopLargeCursor();
            break;

        case 'voiceMode':
            if (enable) startVoiceMode();
            else stopVoiceMode();
            break;

        case 'removeImagesMode':
            enable ? body.classList.add('access-remove-images') : body.classList.remove('access-remove-images');
            break;

        case 'magnifierMode':
            if (enable) startMagnifier();
            else stopMagnifier();
            break;
    }
}

function moveTunnel(e) {
    if(tunnelOverlay) {
        tunnelOverlay.style.transform = `translate(calc(${e.clientX}px - 150px), calc(${e.clientY}px - 150px))`;
    }
}

// -----------------------------------
// Focus Mode Functions
// -----------------------------------
let focusModeHiddenElements = [];

function applyFocusModeEnhancements() {
    const hasMain = document.querySelector('main, article, [role="main"]');
    if (!hasMain) {
        const divs = document.querySelectorAll('body > div, body > section');
        let bestDiv = null;
        let bestTextLen = 0;
        divs.forEach(div => {
            const textLen = (div.innerText || '').length;
            if (textLen > bestTextLen) {
                bestTextLen = textLen;
                bestDiv = div;
            }
        });
        if (bestDiv && bestTextLen > 200) {
            bestDiv.setAttribute('data-sightsync-main', 'true');
            bestDiv.style.maxWidth = '750px';
            bestDiv.style.margin = '0 auto';
            bestDiv.style.padding = '24px';
            bestDiv.style.fontSize = '1.15em';
            bestDiv.style.lineHeight = '1.9';
        }
        divs.forEach(div => {
            if (div !== bestDiv && !div.querySelector('[data-sightsync-main]')) {
                const textLen = (div.innerText || '').length;
                if (textLen < 100) {
                    div.setAttribute('data-sightsync-hidden', 'true');
                    div.style.display = 'none';
                    focusModeHiddenElements.push(div);
                }
            }
        });
    }
}

function removeFocusModeEnhancements() {
    focusModeHiddenElements.forEach(el => {
        el.style.display = '';
        el.removeAttribute('data-sightsync-hidden');
    });
    focusModeHiddenElements = [];
    const fallbackMain = document.querySelector('[data-sightsync-main]');
    if (fallbackMain) {
        fallbackMain.style.maxWidth = '';
        fallbackMain.style.margin = '';
        fallbackMain.style.padding = '';
        fallbackMain.style.fontSize = '';
        fallbackMain.style.lineHeight = '';
        fallbackMain.removeAttribute('data-sightsync-main');
    }
}

// -----------------------------------
// Large Cursor Mode Functions
// -----------------------------------
let largeCursorDot = null;
let largeCursorHalo = null;
let largeCursorMoveHandler = null;

function startLargeCursor() {
    document.body.classList.add('access-large-cursor');

    if (!largeCursorDot) {
        largeCursorDot = document.createElement('div');
        largeCursorDot.className = 'access-large-cursor-dot';
        largeCursorDot.style.left = '-100px';
        largeCursorDot.style.top = '-100px';
        document.documentElement.appendChild(largeCursorDot);
    }
    if (!largeCursorHalo) {
        largeCursorHalo = document.createElement('div');
        largeCursorHalo.className = 'access-large-cursor-halo';
        largeCursorHalo.style.left = '-100px';
        largeCursorHalo.style.top = '-100px';
        document.documentElement.appendChild(largeCursorHalo);
    }

    if (largeCursorMoveHandler) {
        document.removeEventListener('mousemove', largeCursorMoveHandler);
    }

    largeCursorMoveHandler = (e) => {
        requestAnimationFrame(() => {
            if (largeCursorDot) {
                largeCursorDot.style.left = e.clientX + 'px';
                largeCursorDot.style.top = e.clientY + 'px';
            }
            if (largeCursorHalo) {
                largeCursorHalo.style.left = e.clientX + 'px';
                largeCursorHalo.style.top = e.clientY + 'px';
            }
        });
    };
    document.addEventListener('mousemove', largeCursorMoveHandler);
}

function stopLargeCursor() {
    document.body.classList.remove('access-large-cursor');
    if (largeCursorDot) {
        largeCursorDot.remove();
        largeCursorDot = null;
    }
    if (largeCursorHalo) {
        largeCursorHalo.remove();
        largeCursorHalo = null;
    }
    if (largeCursorMoveHandler) {
        document.removeEventListener('mousemove', largeCursorMoveHandler);
        largeCursorMoveHandler = null;
    }
}

// -----------------------------------
// Magnifier Mode Functions
// -----------------------------------
let magnifierLens = null;
let magnifierClone = null;
let magnifierMoveHandler = null;

function startMagnifier() {
    if (magnifierLens) return;

    magnifierLens = document.createElement('div');
    magnifierLens.className = 'sightsync-magnifier';
    
    magnifierClone = document.body.cloneNode(true);
    
    const scripts = magnifierClone.querySelectorAll('script, iframe, video');
    scripts.forEach(s => s.remove());
    
    magnifierClone.className = 'sightsync-magnifier-content';
    magnifierClone.style.width = document.documentElement.scrollWidth + 'px';
    magnifierClone.style.height = document.documentElement.scrollHeight + 'px';
    magnifierLens.appendChild(magnifierClone);
    document.documentElement.appendChild(magnifierLens);

    magnifierMoveHandler = (e) => {
        requestAnimationFrame(() => {
            if (!magnifierLens || !magnifierClone) return;
            const zoom = 2;
            const lensWidth = 600;
            const lensHeight = 400;
            
            let x = e.clientX;
            let y = e.clientY;

            const minX = lensWidth / 2;
            const maxX = window.innerWidth - (lensWidth / 2);
            const minY = lensHeight / 2;
            const maxY = window.innerHeight - (lensHeight / 2);

            if (x < minX) x = minX;
            if (x > maxX) x = maxX;
            if (y < minY) y = minY;
            if (y > maxY) y = maxY;

            magnifierLens.style.left = x + 'px';
            magnifierLens.style.top = y + 'px';

            const cloneX = e.clientX - x + (lensWidth / 2) - (e.pageX * zoom);
            const cloneY = e.clientY - y + (lensHeight / 2) - (e.pageY * zoom);
            
            magnifierClone.style.transform = `translate(${cloneX}px, ${cloneY}px) scale(${zoom})`;
        });
    };

    document.addEventListener('mousemove', magnifierMoveHandler);
    magnifierLens.classList.add('active');
}

function stopMagnifier() {
    if (magnifierMoveHandler) {
        document.removeEventListener('mousemove', magnifierMoveHandler);
        magnifierMoveHandler = null;
    }
    if (magnifierLens) {
        magnifierLens.remove();
        magnifierLens = null;
    }
    magnifierClone = null;
}

// -----------------------------------
// Voice Mode Functions
// -----------------------------------
let currentVoiceElement = null;

function startVoiceMode() {
    isVoiceModeEnabled = true;
    if (!debouncedMouseMove) {
        debouncedMouseMove = debounce(handleMouseMove, 200);
    }
    window.addEventListener('mousemove', debouncedMouseMove);
}

function stopVoiceMode() {
    isVoiceModeEnabled = false;
    window.speechSynthesis.cancel();
    if (currentVoiceElement) {
        currentVoiceElement.classList.remove('voice-highlight');
        currentVoiceElement = null;
    }
    if (debouncedMouseMove) {
        window.removeEventListener('mousemove', debouncedMouseMove);
    }
}

function handleMouseMove(e) {
    if (!isVoiceModeEnabled) return;
    const element = document.elementFromPoint(e.clientX, e.clientY);
    if (!element) return;
    const readableElement = element.closest('p, h1, h2, h3, h4, h5, h6, li, span, div') || element;
    const text = readableElement.innerText ? readableElement.innerText.trim() : "";
    if (text.length < 5) return;
    if (readableElement !== currentVoiceElement) {
        readElement(readableElement);
    }
}

function readElement(el) {
    window.speechSynthesis.cancel();
    if (currentVoiceElement) {
        currentVoiceElement.classList.remove('voice-highlight');
    }
    currentVoiceElement = el;
    currentVoiceElement.classList.add('voice-highlight');
    const textToRead = el.innerText.trim();
    const utterance = new SpeechSynthesisUtterance(textToRead);
    window.speechSynthesis.speak(utterance);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// -----------------------------------
// Keyboard Shortcuts for Modes
// -----------------------------------

document.addEventListener('keydown', (e) => {
    if (e.target && (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName) || e.target.isContentEditable)) {
        return;
    }

    if (e.key.match(/^F([1-9]|1[0-2])$/)) {
        e.preventDefault();
        if (!isLoggedIn) {
            showLoginModal();
            return;
        }

        switch(e.key) {
            case 'F1': toggleMode('highContrastMode'); break;
            case 'F2': toggleMode('lowVisionMode'); break;
            case 'F3': toggleMode('colorBlindMode'); break;
            case 'F4': toggleMode('tunnelVisionMode'); break;
            case 'F5': toggleMode('peripheralLossMode'); break;
            case 'F6': toggleMode('blurryVisionMode'); break;
            case 'F7': toggleMode('focusMode'); break;
            case 'F8': toggleMode('smartHighlightMode'); break;
            case 'F9': toggleMode('largeCursorMode'); break;
            case 'F10': toggleMode('voiceMode'); break;
            case 'F11': toggleMode('removeImagesMode'); break;
            case 'F12': toggleMode('magnifierMode'); break;
        }
    }
});
